#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 20;
int main(){
    int n;
     cout<<"Enter number of processes: "; 
     cin>>n;
    int pid[MAX], at[MAX], bt[MAX], rem[MAX], pr[MAX], ct[MAX]={0}, tat[MAX]={0}, wt[MAX]={0};
    for(int i=0;i<n;i++){ pid[i]=i+1; cout<<"P"<<pid[i]<<" AT BT PR: "; 
        cin>>at[i]>>bt[i]>>pr[i]; 
        rem[i]=bt[i]; }
    
    int t=0, finished=0;
    while(finished < n){
        int idx = -1;
        int bestPr = 1e9;
        for(int i=0;i<n;i++){
            if(at[i] <= t && rem[i] > 0){
                if(pr[i] < bestPr)
                { bestPr = pr[i]; idx = i; }
                else if(pr[i] == bestPr){
                    // tie-break: smaller remaining time, then earlier arrival, then smaller PID
                    if(idx == -1) idx = i;
                    else if(rem[i] < rem[idx]) idx = i; //check rem time of both
                    else if(rem[i] == rem[idx] && at[i] < at[idx]) idx = i;//if rem time same chek at
                    else if(rem[i] == rem[idx] && at[i] == at[idx] && pid[i] < pid[idx]) idx = i;//lastl check pid
                }
            }
        }

        if(idx == -1){ t++; continue; }    // CPU idle
        rem[idx]--;                         // execute 1 unit
        t++;
        if(rem[idx] == 0){                  // finished
            ct[idx] = t;
            tat[idx] = ct[idx] - at[idx];
            wt[idx] = tat[idx] - bt[idx];
            finished++;
        }
    }

    double sumT=0, sumW=0;
    cout<<"\nPID\tAT\tBT\tPR\tCT\tTAT\tWT\n";
    for(int i=0;i<n;i++){ 
        cout<<pid[i]<<'\t'<<at[i]<<'\t'<<bt[i]<<'\t'<<pr[i]<<'\t'<<ct[i]<<'\t'<<tat[i]<<'\t'<<wt[i]<<'\n';
        sumT += tat[i]; sumW += wt[i];
    }
    cout<<fixed<<setprecision(2)<<"\nAverage TAT = "<<sumT/n<<"\nAverage WT = "<<sumW/n<<"\n";
    return 0;
}
