#include <iostream>
#include <limits>
using namespace std;

/* find page in frames, return index or -1   To check whether a page is already present inside the physical memory (frames).*/
int findInFrames(int frames[], int fcount, int page) {
    for (int i = 0; i < fcount; ++i) if (frames[i] == page) return i;
    return -1;
}

/* FIFO simulation */
void simulate_fifo(int refs[], int nrefs, int framesCount, int &hits, int &faults) {
    const int MAXF = 100;
    int frames[MAXF];
    for (int i = 0; i < framesCount; ++i) 
    frames[i] = -1;

    int fifoPtr = 0;
    hits = faults = 0;
    for (int t = 0; t < nrefs; ++t) {
        int p = refs[t];
        if (findInFrames(frames, framesCount, p) != -1) { ++hits; }
        else {
            ++faults; // there is page fault then check if there is available space  if yes then store its index in freeidx=i
            int freeIdx = -1;
            for (int i = 0; i < framesCount; ++i) 
            if (frames[i] == -1) {
                 freeIdx = i; //empty frame is found
                  break; }

            if (freeIdx != -1) //There is an empty frame when first condition false this becomes true
            frames[freeIdx] = p; //Simply put the page p in that empty frame

            else { frames[fifoPtr] = p; 
                fifoPtr = (fifoPtr + 1) % framesCount; }
        }
    }
}

/* LRU simulation */
void simulate_lru(int refs[], int nrefs, int framesCount, int &hits, int &faults) {
    const int MAXF = 100;
    int frames[MAXF], lastUsed[MAXF];
    for (int i = 0; i < framesCount; ++i)
     { frames[i] = -1; lastUsed[i] = -1; }
    hits = faults = 0;
    for (int t = 0; t < nrefs; ++t) {
        int p = refs[t];
        int idx = findInFrames(frames, framesCount, p);
        if (idx != -1) { ++hits; lastUsed[idx] = t; }
        else {
            ++faults;
            int freeIdx = -1;
            for (int i = 0; i < framesCount; ++i) 
            if (frames[i] == -1) { freeIdx = i; break; }
            if (freeIdx != -1) { frames[freeIdx] = p; lastUsed[freeIdx] = t; }
            else {
                int oldest = INT_MAX;//oldest will hold the smallest lastUsed value found so far (smallest = used longest ago).
                int victim = 0;
                for (int i = 0; i < framesCount; ++i)
                if (lastUsed[i] < oldest)
                 { oldest = lastUsed[i];  
                    victim = i; } //After the loop, victim is the index of the frame with the smallest lastUsed timestamp (i.e., least recently used).
                frames[victim] = p;
                lastUsed[victim] = t;
            }
        }
    }
}

/* Optimal simulation */
void simulate_opt(int refs[], int nrefs, int framesCount, int &hits, int &faults) {
    const int MAXF = 100;
    int frames[MAXF];
    for (int i = 0; i < framesCount; ++i)
     frames[i] = -1;

    hits = faults = 0;
    for (int t = 0; t < nrefs; ++t) {
        int p = refs[t];
        if (findInFrames(frames, framesCount, p) != -1) { ++hits; }
        else {
            ++faults;
            int freeIdx = -1;
            for (int i = 0; i < framesCount; ++i) 
            if (frames[i] == -1) { freeIdx = i; 
                break; }
            if (freeIdx != -1) 
            { frames[freeIdx] = p; }
            else {
                //till this
                int chosen = 0, farthest = -1;
                for (int i = 0; i < framesCount; ++i) {
                     int nextpos = nrefs + 1;
                    for (int k = t + 1; k < nrefs; ++k)//               We scan from t+1 because:At t, the page is being accessed NOW
                     if (refs[k] == frames[i])                            // We want to find when it will be used NEXT                                                    
                       { nextpos = k; break; } 
                                                    //So the scan must begin from the next time step 
                    if (nextpos > farthest)
                     { farthest = nextpos; 
                        chosen = i; }  
                }
                frames[chosen] = p;
            }
        }
    }
}

/* Helper to print results */
void printResult(const char *name, int hits, int faults, int nrefs) {
    double faultRate = (nrefs == 0) ? 0.0 : (100.0 * faults / nrefs);
    cout << name << " -> Refs: " << nrefs << " Hits: " << hits << " Faults: " << faults
         << " FaultRate: " << faultRate << "%\n";
}

int main() {
    const int MAXR = 1000;
    int refs[MAXR];
    int nrefs, framesCount;
    cout << "Enter number of references: ";
    if (!(cin >> nrefs)) return 0;
    cout << "Enter reference string (space separated " << nrefs << " values):\n";
    for (int i = 0; i < nrefs && i < MAXR; ++i) 
    cin >> refs[i];

    cout << "Enter number of frames: ";
    cin >> framesCount;
    if (framesCount <= 0 || framesCount > 100) { cout << "Invalid frame count\n"; return 0; }

    cout << "\nChoose option:\n1 - FIFO\n2 - LRU\n3 - OPTIMAL\n4 - RUN ALL (compare)\nEnter choice: ";
    int choice; cin >> choice;
    cout << "\n";

    if (choice == 1 || choice == 4) {
        int hits, faults;
        simulate_fifo(refs, nrefs, framesCount, hits, faults);
        printResult("FIFO", hits, faults, nrefs);
        if (choice != 4) return 0;
    }
    if (choice == 2 || choice == 4) {
        int hits, faults;
        simulate_lru(refs, nrefs, framesCount, hits, faults);
        printResult("LRU", hits, faults, nrefs);
        if (choice != 4) return 0;
    }
    if (choice == 3 || choice == 4) {
        int hits, faults;
        simulate_opt(refs, nrefs, framesCount, hits, faults);
        printResult("OPTIMAL", hits, faults, nrefs);
    }

    return 0;
}

