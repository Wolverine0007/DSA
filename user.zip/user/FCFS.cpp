#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 20;

int main() {
    int n;
    cout<<"Enter number of processes: ";
    cin>>n;

    int pid[MAX], at[MAX], bt[MAX], ct[MAX], tat[MAX], wt[MAX];

    for(int i=0;i<n;i++){
        pid[i] = i+1;
        cout<<"P"<<pid[i]<<" AT BT: ";
        cin>>at[i]>>bt[i];
    }

    // sort processes by arrival time
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(at[j] < at[i]){
                swap(at[i], at[j]);
                swap(bt[i], bt[j]);
                swap(pid[i], pid[j]);
            }
        }
    }

    // FCFS execution
    int t = 0;
    for(int i=0;i<n;i++){
        if(t < at[i]) t = at[i];
       
        t += bt[i];
        ct[i] = t;
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
    }

    // output
    cout<<"\nPID\tAT\tBT\tCT\tTAT\tWT\n";
    double sumT=0, sumW=0;

    for(int i=0;i<n;i++){
        cout<<pid[i]<<"\t"<<at[i]<<"\t"<<bt[i]<<"\t"<<ct[i]<<"\t"<<tat[i]<<"\t"<<wt[i]<<"\n";
        sumT += tat[i];
        sumW += wt[i];
    }

    cout<<fixed<<setprecision(2);
    cout<<"\nAverage TAT = "<<sumT/n;
    cout<<"\nAverage WT = "<<sumW/n<<"\n";

    return 0;
}
