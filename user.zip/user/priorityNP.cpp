#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 20;

int main() {
    int n;
    cout<<"Enter number of processes: ";
    cin>>n;

    int pid[MAX], at[MAX], bt[MAX], pr[MAX], ct[MAX], tat[MAX], wt[MAX], done[MAX]={0};

    for(int i=0;i<n;i++){
        pid[i] = i+1;
        cout<<"P"<<pid[i]<<" AT BT PR: ";        // PR = Priority
        cin>>at[i]>>bt[i]>>pr[i];
    }

    int t=0, finished=0;

    while(finished < n){
        int idx = -1, bestPr = 1e9;

        for(int i=0;i<n;i++){
            if(!done[i] && at[i] <= t && pr[i] < bestPr){
                bestPr = pr[i];
                idx = i;
            }
        }

        if(idx == -1){ t++; continue; }   // CPU idle

        t += bt[idx]; //t += bt[idx] assumes the process runs until completion immediately — it ignores arrivals that happen during that interval.
        ct[idx] = t;
        tat[idx] = ct[idx] - at[idx];
        wt[idx]  = tat[idx] - bt[idx];
        done[idx] = 1;
        finished++;
    }

    cout<<"\nPID\tAT\tBT\tPR\tCT\tTAT\tWT\n";
    double sumT=0, sumW=0;

    for(int i=0;i<n;i++){
        cout<<pid[i]<<"\t"<<at[i]<<"\t"<<bt[i]<<"\t"<<pr[i]<<"\t"<<ct[i]
            <<"\t"<<tat[i]<<"\t"<<wt[i]<<"\n";
        sumT += tat[i];
        sumW += wt[i];
    }

    cout<<fixed<<setprecision(2);
    cout<<"\nAverage TAT = "<<sumT/n<<"\n";
    cout<<"Average WT = "<<sumW/n<<"\n";

    return 0;
}
