#include <iostream>
#include <sys/ipc.h>   // IPC flags/structures
#include <sys/shm.h>   // Shared Memory
#include <sys/msg.h>   // Message Queues
#include <unistd.h>    // fork()
#include <sys/wait.h>  // wait()
#include <cstring>     // memcpy, strcpy

// --- 1. Implementation using Shared Memory ---

void shared_memory_example() {
    std::cout << "\n--- Shared Memory IPC Example ---\n";

    // 1. Generate a unique key for the IPC resource
    key_t key = ftok("ipc_examples.cpp", 65);
    if (key == -1) {
        perror("ftok");
        return;
    }

    const size_t SHM_SIZE = 1024; // 1 KB segment size
    int shmid; // Shared Memory Identifier
    char *shared_data; // Pointer to the shared data

    // 2. Create the shared memory segment
    // IPC_CREAT: create if key does not exist
    // 0666: permissions (read/write for all)
    shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        return;
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        // Clean up the segment if fork fails
        shmctl(shmid, IPC_RMID, NULL);
        return;
    } else if (pid > 0) { // PARENT PROCESS (Writer)
        std::cout << "Parent (PID: " << getpid() << ") starting...\n";

        // 3. Attach the shared memory segment to the process's address space
        shared_data = (char *)shmat(shmid, NULL, 0);
        if (shared_data == (char *)-1) {
            perror("shmat (Parent)");
            return;
        }

        const char* message = "Hello from Parent via Shared Memory!";
        std::cout << "Parent: Writing message: '" << message << "'\n";

        // 4. Write data to the shared memory
        strncpy(shared_data, message, SHM_SIZE - 1);
        shared_data[SHM_SIZE - 1] = '\0'; // Ensure null-termination

        // 5. Detach the segment
        if (shmdt(shared_data) == -1) {
            perror("shmdt (Parent)");
        }

        // Wait for the child to finish
        wait(NULL);

        // 6. Delete (remove) the shared memory segment
        if (shmctl(shmid, IPC_RMID, NULL) == -1) {
            perror("shmctl (IPC_RMID)");
        }
        std::cout << "Parent: Shared Memory segment cleaned up.\n";

    } else { // CHILD PROCESS (Reader)
        std::cout << "Child (PID: " << getpid() << ") starting...\n";

        // Wait a moment to ensure parent has time to write (demonstration only)
        sleep(1);

        // 3. Attach the shared memory segment to the process's address space
        // Use the same shmid obtained by the parent
        shared_data = (char *)shmat(shmid, NULL, 0);
        if (shared_data == (char *)-1) {
            perror("shmat (Child)");
            return;
        }

        // 4. Read data from the shared memory
        std::cout << "Child: Reading message: '" << shared_data << "'\n";

        // 5. Detach the segment
        if (shmdt(shared_data) == -1) {
            perror("shmdt (Child)");
        }
    }
}

// --- 2. Implementation using Message Passing (Message Queues) ---

// Define the structure for a message
struct message_buffer {
    long mtype; // Required by the message queue API (must be > 0)
    char mtext[100]; // Message data
};

void message_passing_example() {
    std::cout << "\n--- Message Passing IPC Example ---\n";

    // 1. Generate a unique key for the IPC resource
    key_t key = ftok("ipc_examples.cpp", 66);
    if (key == -1) {
        perror("ftok");
        return;
    }

    int msqid; // Message Queue Identifier

    // 2. Create the message queue
    msqid = msgget(key, IPC_CREAT | 0666);
    if (msqid < 0) {
        perror("msgget");
        return;
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        // Clean up the queue if fork fails
        msgctl(msqid, IPC_RMID, NULL);
        return;
    } else if (pid > 0) { // PARENT PROCESS (Sender)
        std::cout << "Parent (PID: " << getpid() << ") starting...\n";

        message_buffer sbuf;
        sbuf.mtype = 1; // Message type (can be used for filtering)
        strcpy(sbuf.mtext, "Greetings from Parent via Message Queue!");
        int msg_size = strlen(sbuf.mtext) + 1;

        std::cout << "Parent: Sending message: '" << sbuf.mtext << "'\n";

        // 3. Send the message
        // IPC_NOWAIT: return immediately if queue is full
        if (msgsnd(msqid, &sbuf, msg_size, IPC_NOWAIT) < 0) {
            perror("msgsnd");
        }

        // Wait for the child to finish
        wait(NULL);

        // 4. Delete (remove) the message queue
        if (msgctl(msqid, IPC_RMID, NULL) < 0) {
            perror("msgctl (IPC_RMID)");
        }
        std::cout << "Parent: Message Queue cleaned up.\n";

    } else { // CHILD PROCESS (Receiver)
        std::cout << "Child (PID: " << getpid() << ") starting...\n";

        message_buffer rbuf;
        long msg_type_to_receive = 1;

        // Wait a moment to ensure parent sends the message
        sleep(1);

        std::cout << "Child: Waiting to receive message of type " << msg_type_to_receive << "...\n";

        // 3. Receive the message
        // 0: blocks until a message is received
        if (msgrcv(msqid, &rbuf, sizeof(rbuf.mtext), msg_type_to_receive, 0) < 0) {
            perror("msgrcv");
        } else {
            std::cout << "Child: Received message: '" << rbuf.mtext << "'\n";
        }
    }
}

int main() {
    // Note: Compile this file using a C++ compiler on a Linux/Unix system, 
    // and remember to link the necessary libraries (often implicitly linked, 
    // but sometimes explicit flags like -lrt are needed for some IPC systems).

    shared_memory_example();
    message_passing_example();

    return 0;
}
