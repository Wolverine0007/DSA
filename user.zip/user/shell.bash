#!/bin/bash
echo "Disk Space Usage:"
echo "----------------------------------------"
df -h | grep '^/dev' | while read fs size used avail usep mount
do
echo "Filesystem : $fs"
echo " Total Space : $size"
echo " Used Space : $used"
echo " Available : $avail"
echo " Usage Percent : $usep"
echo "----------------------------------------"
done