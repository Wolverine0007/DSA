#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 20;
int main() {
    int n; 
    cout<<"Enter number of processes: "; cin>>n;
    int pid[MAX], at[MAX], bt[MAX], ct[MAX]={0}, tat[MAX]={0}, wt[MAX]={0}, done[MAX]={0};
    for(int i=0;i<n;i++)
    { pid[i]=i+1; 
        cout<<"P"<<pid[i]<<" AT BT: "; 
        cin>>at[i]>>bt[i]; }
   
    int t=0, finished=0;
    while(finished<n){
        int idx=-1, minb=1e9;
        for(int i=0;i<n;i++){
            if(!done[i] && at[i]<=t && bt[i]<minb)
            { minb=bt[i]; 
                idx=i; }
        }
        
        if(idx==-1) //No process has arrived yet ,No process is ready to execute at current time t
        { t++; continue; }
        
        t += bt[idx];
        ct[idx]=t;
        tat[idx]=ct[idx]-at[idx];
        wt[idx]=tat[idx]-bt[idx];
        done[idx]=1; 
        finished++;
    }
    double sumT=0,sumW=0;
    cout<<"\nPID\tAT\tBT\tCT\tTAT\tWT\n";
    for(int i=0;i<n;i++){
        cout<<pid[i]<<'\t'<<at[i]<<'\t'<<bt[i]<<'\t'<<ct[i]<<'\t'<<tat[i]<<'\t'<<wt[i]<<'\n';
        sumT+=tat[i]; sumW+=wt[i];
    }
    cout<<fixed<<setprecision(2)<<"\nAverage TAT = "<<sumT/n<<"\nAverage WT = "<<sumW/n<<"\n";
    return 0;
}
