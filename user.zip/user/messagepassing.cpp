#include <iostream>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <unistd.h>
#include <cstring>
using namespace std;

#define MSG_KEY 5678
struct message {
    long msg_type;
    char msg_text[100];
};
int main() {
    int msgid;
    message msg;
    msgid = msgget(MSG_KEY, IPC_CREAT | 0666);
    if (msgid < 0) {
        perror("msgget failed");
        return 1;
    }
    pid_t pid = fork();

    if (pid == 0) {
       
        sleep(2); 
        if (msgrcv(msgid, &msg, sizeof(msg.msg_text), 1, 0) < 0) {
            perror("msgrcv failed");
            return 1;
        }
        cout << "Child Process (Receiver): Message received: " << msg.msg_text << endl;
    } else {
        cout << "Parent Process (Sender): Enter a message to send: ";
        string data;
        getline(cin, data);

        msg.msg_type = 1;
        strncpy(msg.msg_text, data.c_str(), sizeof(msg.msg_text));

        if (msgsnd(msgid, &msg, sizeof(msg.msg_text), 0) < 0) {
            perror("msgsnd failed");
            return 1;
        }
        wait(NULL);
        msgctl(msgid, IPC_RMID, NULL);
    }
    return 0;
}
